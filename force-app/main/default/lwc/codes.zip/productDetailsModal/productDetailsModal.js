import { LightningElement, api } from 'lwc';

export default class ProductDetailsModal extends LightningElement {

    @api productdetails;
}